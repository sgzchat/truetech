<?php 
session_start();

$con = mysql_connect("localhost","root","");
$db = mysql_select_db("truetech") or die(mysql_error());
?>